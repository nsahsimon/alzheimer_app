package com.example.alheimer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
