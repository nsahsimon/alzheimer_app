import 'package:alheimer/views/home/start_analyze_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';

class LoginController extends GetxController {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  RxDouble emailfieldHeight=40.0.obs;
  RxDouble  passwordHeight=40.0.obs;

  GlobalKey<FormState> loginFormKey = GlobalKey<FormState>();

  RxBool isLoading = false.obs;


  void loginButtonFunction() {
    final isValid = loginFormKey.currentState!.validate();
    if (isValid) {
      Get.to(()=> const StartAnalyzeScreen());
    } else
      if (kDebugMode) {
        print("not ok");
      }
  }



  String? validateName(String value) {
    if (value == '') {
      return "Enter your name";
    }
    return null;
  }
  String? validatePassword(String value) {
    if (value.isEmpty) {
      passwordHeight.value=60.0;
      return 'Please enter password';

    }
    passwordHeight.value=40.0;
    return null;
  }

  @override
  void onClose() {
    loginFormKey.currentState?.dispose(); // Dispose of the GlobalKey
    super.onClose();
  }
}
