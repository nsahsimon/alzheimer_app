import 'package:flutter/material.dart';

const Color kButtonColor = Color(0xff7300E6);
const Color kBlackColor = Colors.black;
const Color kGreenButtonColor = Color(0xff02802F);
const Color kBackgroundColor = Color(0xffF2E6FF);
const Color kBackgroundColorStartAnalyze = Colors.white;
const Color kButtonColorStartAnalyze = Color(0xff6E0280);
const Color kButtonColorStartAnalyzeLite = Color(0xffeb81fd);
